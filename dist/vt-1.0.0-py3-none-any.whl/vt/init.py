#!/usr/bin/env python3
"""
vt init
"""
import subprocess

subprocess.run(["bash", "vt/init.sh"])